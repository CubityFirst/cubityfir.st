R = Reset
Alt + F4 = Quit

:)